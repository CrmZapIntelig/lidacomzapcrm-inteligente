/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  loadData,
  saveData,
  INITIAL_CLIENTS,
  INITIAL_MESSAGES,
  INITIAL_HISTORY,
  INITIAL_CAMPAIGNS,
  INITIAL_ORDERS,
  INITIAL_AUTOMATIONS,
  DEFAULT_SETTINGS,
  INITIAL_PRODUCTS_DIGITAL_MENU,
  INITIAL_CARDAPIOS,
  INITIAL_DELIVERY_ORDERS,
  INITIAL_COURIERS,
  INITIAL_ROUTES,
  INITIAL_COURIER_REVIEWS,
  INITIAL_DELIVERY_HISTORIES,
} from './utils/mockData';
import { Client, Message, HistoryEvent, Order, Campaign, AutomationRule, AppSettings, FunnelStage, Courier, DeliveryRoute, CourierReview, DeliveryHistory } from './types';

// Import Views
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardView from './components/DashboardView';
import WhatsAppView from './components/WhatsAppView';
import CrmKanbanView from './components/CrmKanbanView';
import CampanhasView from './components/CampanhasView';
import DisparadorView from './components/DisparadorView';
import CardapioView from './components/CardapioView';
import CozinhaView from './components/CozinhaView';
import ProducaoView from './components/ProducaoView';
import EntregasView from './components/EntregasView';
import EntregadoresView from './components/EntregadoresView';
import RotasView from './components/RotasView';
import RastreamentoView from './components/RastreamentoView';
import ClientesView from './components/ClientesView';
import AutomationsView from './components/AutomationsView';
import CentralInteligenteView from './components/CentralInteligenteView';
import RelatoriosView from './components/RelatoriosView';
import ConfiguracoesView from './components/ConfiguracoesView';
import OrderModal from './components/OrderModal';
import LoginView from './components/LoginView';
import CaixaView from './components/CaixaView';
import { ShoppingBag, Star, TrendingUp } from 'lucide-react';
import { AuthSession, User, CaixaSession, CaixaTransaction } from './types';

export default function App() {
  // Auth state
  const [auth, setAuth] = useState<AuthSession>(() => {
    const saved = localStorage.getItem('lidacomzap_auth');
    return saved ? JSON.parse(saved) : { user: null, token: null, isAuthenticated: false };
  });

  const handleLogin = (user: User) => {
    const newAuth = { user, token: 'mock_token', isAuthenticated: true };
    setAuth(newAuth);
    localStorage.setItem('lidacomzap_auth', JSON.stringify(newAuth));
  };

  const handleLogout = () => {
    setAuth({ user: null, token: null, isAuthenticated: false });
    localStorage.removeItem('lidacomzap_auth');
  };

  // 1. Core State Managers backed by LocalStorage
  const [clients, setClients] = useState<Client[]>(() => loadData('clients', INITIAL_CLIENTS));
  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    const loaded = loadData<Record<string, Message[]>>('messages', INITIAL_MESSAGES);
    const sanitized: Record<string, Message[]> = {};
    for (const key in loaded) {
      const list = loaded[key] || [];
      const seen = new Set<string>();
      const uniqueMsg: Message[] = [];
      list.forEach((m) => {
        let cleanId = m.id;
        if (!cleanId) {
          cleanId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        }
        if (seen.has(cleanId)) {
          cleanId = `${cleanId}_dup_${Math.random().toString(36).substring(2, 9)}`;
        }
        seen.add(cleanId);
        uniqueMsg.push({ ...m, id: cleanId });
      });
      sanitized[key] = uniqueMsg;
    }
    return sanitized;
  });
  const [history, setHistory] = useState<HistoryEvent[]>(() => loadData('history', INITIAL_HISTORY));
  const [campaigns, setCampaigns] = useState<Campaign[]>(() => loadData('campaigns', INITIAL_CAMPAIGNS));
  const [orders, setOrders] = useState<Order[]>(() => loadData('orders', INITIAL_ORDERS));
  const [automations, setAutomations] = useState<AutomationRule[]>(() => loadData('automations', INITIAL_AUTOMATIONS));
  const [settings, setSettings] = useState<AppSettings>(() => loadData('settings', DEFAULT_SETTINGS));
  const [productsDigitalMenu, setProductsDigitalMenu] = useState(() => loadData('productsDigitalMenu', INITIAL_PRODUCTS_DIGITAL_MENU));
  const [cardapios, setCardapios] = useState(() => loadData('cardapios', INITIAL_CARDAPIOS));
  const [deliveryOrders, setDeliveryOrders] = useState(() => loadData('deliveryOrders', INITIAL_DELIVERY_ORDERS));
  const [couriers, setCouriers] = useState<Courier[]>(() => loadData('couriers', INITIAL_COURIERS));
  const [routes, setRoutes] = useState<DeliveryRoute[]>(() => loadData('routes', INITIAL_ROUTES));
  const [reviews, setReviews] = useState<CourierReview[]>(() => loadData('reviews', INITIAL_COURIER_REVIEWS));
  const [deliveryHistories, setDeliveryHistories] = useState<DeliveryHistory[]>(() => loadData('deliveryHistories', INITIAL_DELIVERY_HISTORIES));

  // 2. Navigation & UI controls
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Active client details in Chat
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  // Order modal triggers
  const [clientForOrder, setClientForOrder] = useState<Client | null>(null);

  // Sync to storage on state changes
  useEffect(() => {
    saveData('clients', clients);
  }, [clients]);

  useEffect(() => {
    saveData('messages', messages);
  }, [messages]);

  useEffect(() => {
    saveData('history', history);
  }, [history]);

  useEffect(() => {
    saveData('campaigns', campaigns);
  }, [campaigns]);

  useEffect(() => {
    saveData('orders', orders);
  }, [orders]);

  useEffect(() => {
    saveData('automations', automations);
  }, [automations]);

  useEffect(() => {
    saveData('settings', settings);
  }, [settings]);

  useEffect(() => {
    saveData('productsDigitalMenu', productsDigitalMenu);
  }, [productsDigitalMenu]);

  useEffect(() => {
    saveData('cardapios', cardapios);
  }, [cardapios]);

  useEffect(() => {
    saveData('deliveryOrders', deliveryOrders);
  }, [deliveryOrders]);

  useEffect(() => {
    saveData('couriers', couriers);
  }, [couriers]);

  useEffect(() => {
    saveData('routes', routes);
  }, [routes]);

  useEffect(() => {
    saveData('reviews', reviews);
  }, [reviews]);

  useEffect(() => {
    saveData('deliveryHistories', deliveryHistories);
  }, [deliveryHistories]);

  // Handle active class settings matching 'dark' theme on DOM root
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  // Sincronizar Supabase simulation
  const handleTriggerSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      // Generate nice notification event
      const newEvent: HistoryEvent = {
        id: `h_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        clientId: 'system',
        type: 'system_alert',
        title: 'Sincronização Supabase',
        description: 'Conexão sincronizada. Sincronismo integral efetuado com sucesso!',
        timestamp: new Date().toISOString(),
        operatorName: settings.operatorName,
      };
      setHistory((prev) => [newEvent, ...prev]);
      alert('Sincronização com o Supabase efetuada com sucesso! 0 novos leads inseridos.');
    }, 1200);
  };

  // Factory Database Reset
  const handleResetDatabase = () => {
    setClients(INITIAL_CLIENTS);
    setMessages(INITIAL_MESSAGES);
    setHistory(INITIAL_HISTORY);
    setCampaigns(INITIAL_CAMPAIGNS);
    setOrders(INITIAL_ORDERS);
    setAutomations(INITIAL_AUTOMATIONS);
    setSettings(DEFAULT_SETTINGS);
    setProductsDigitalMenu(INITIAL_PRODUCTS_DIGITAL_MENU);
    setCardapios(INITIAL_CARDAPIOS);
    setDeliveryOrders(INITIAL_DELIVERY_ORDERS);
    setSelectedClient(null);
    setCurrentTab('dashboard');
  };

  // 3. Central History Logger
  const handleAddHistoryEvent = (clientId: string, type: any, title: string, description: string) => {
    const newEvent: HistoryEvent = {
      id: `h_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      clientId,
      type,
      title,
      description,
      timestamp: new Date().toISOString(),
      operatorName: settings.operatorName,
    };
    setHistory((prev) => [newEvent, ...prev]);
  };

  // 4. Client modification callback
  const handleUpdateClient = (updated: Client) => {
    setClients((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    // If we're updating the currently focused client inside WhatsApp Chat, update focus state too
    if (selectedClient && selectedClient.id === updated.id) {
      setSelectedClient(updated);
    }
  };

  // 5. Intelligent chatbot simulation on message sent
  const handleSendMessage = (clientId: string, text: string, type: any = 'text', fileName?: string) => {
    const timeNow = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const targetClient = clients.find((c) => c.id === clientId);
    const clientChannel = targetClient?.channel === 'ambos' || !targetClient?.channel ? 'whatsapp' : targetClient.channel;

    const operatorMsg: Message = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      sender: 'operador',
      text,
      timestamp: timeNow,
      type,
      fileName,
      channel: clientChannel,
    };

    // Append to list
    setMessages((prev) => {
      const existing = prev[clientId] || [];
      return { ...prev, [clientId]: [...existing, operatorMsg] };
    });

    // Toggle Automation check SE "mensagem enviada" ENTÃO "Etapa = Lead"
    if (targetClient && targetClient.stage === 'Rascunho') {
      const isLeadRuleActive = automations.find((a) => a.id === 'aut_2')?.active;
      if (isLeadRuleActive) {
        const updated = { ...targetClient, stage: 'Lead' as const };
        handleUpdateClient(updated);
        handleAddHistoryEvent(clientId, 'stage_change', 'Automação (Gatilho)', 'Automação disparada: Rascunho atualizado AUTOMATICAMENTE para LEAD após envio de mensagem proativa.');
      }
    }

    // Trigger AI Simulated reply if the sender was operator and not a silent attachments system.
    if (type === 'text') {
      setTimeout(() => {
        // Compute smart responder text
        let replyText = 'Perfeito! Vou avaliar aqui e te aviso.';
        const lowerText = text.toLowerCase();
        
        if (lowerText.includes('catalogo') || lowerText.includes('catálogo')) {
          replyText = 'Nossa, que peças lindas! Qual o frete convencional para o Rio de Janeiro?';
        } else if (lowerText.includes('cupom') || lowerText.includes('desconto')) {
          replyText = 'Quero cupom sim! Me manda o Pix que vou fechar agora!';
        } else if (lowerText.includes('boleto')) {
          replyText = 'Certo, vou fazer o pagamento amanhã de manhã sem falta.';
        } else if (lowerText.includes('jaqueta') || lowerText.includes('blazer')) {
          replyText = 'Esse modelo tem tamanho P disponível também? Ou só M?';
        }

        const clientMsg: Message = {
          id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          sender: 'cliente',
          text: replyText,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          channel: clientChannel,
        };

        // Append response
        setMessages((prev) => {
          const list = prev[clientId] || [];
          return { ...prev, [clientId]: [...list, clientMsg] };
        });

        // Toggle Automation check SE "cliente respondeu" ENTÃO "Etapa = Em Atendimento"
        if (targetClient && targetClient.stage !== 'Em atendimento') {
          const isMsgReplyRuleActive = automations.find((a) => a.id === 'aut_3')?.active;
          if (isMsgReplyRuleActive) {
            // Get freshly-updated client stage
            setClients((currentClients) => {
              const currentTarget = currentClients.find((c) => c.id === clientId);
              if (currentTarget && currentTarget.stage !== 'Em atendimento') {
                const finalUpdated = { ...currentTarget, stage: 'Em atendimento' as const };
                // Also trigger historic logging
                handleAddHistoryEvent(clientId, 'stage_change', 'Automação (Resposta)', 'Automação disparada: Mover para EM ATENDIMENTO após resposta automática recebida do lead.');
                
                // If focused in chat
                if (selectedClient && selectedClient.id === clientId) {
                  setSelectedClient(finalUpdated);
                }
                
                return currentClients.map((c) => (c.id === clientId ? finalUpdated : c));
              }
              return currentClients;
            });
          }
        }
      }, 1500);
    }
  };

  // 6. Billing order submission callback
  const handleSaveOrderCreated = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);

    // Bind orders status stats to customer total comprado
    const targetCli = clients.find((c) => c.id === newOrder.clientId);
    if (targetCli) {
      const boughtUpdate = newOrder.status === 'Pago' 
        ? targetCli.totalBought + newOrder.total 
        : targetCli.totalBought;

      // Update client funnel stage to 'Pedido gerado' or 'Pago' automatically
      let stageVal: FunnelStage = 'Pedido gerado';
      let ruleTriggerTitle = 'Automação (Pedido Gerado)';
      let ruleTriggerText = 'Novo faturamento emitido no modal: Etapa atualizada AUTOMATICAMENTE para PEDIDO GERADO.';

      if (newOrder.status === 'Pago') {
        stageVal = 'Pago';
        ruleTriggerTitle = 'Automação (Pagamento Aprovado)';
        ruleTriggerText = 'Ordem financeira gerada como PAGA: Etapa atualizada AUTOMATICAMENTE para PAGO.';
      }

      // Check toggled automations
      const isPedidoRuleActive = automations.find((a) => a.id === 'aut_4')?.active;
      const isPagoRuleActive = automations.find((a) => a.id === 'aut_5')?.active;

      const finalStage = (stageVal === 'Pedido gerado' && isPedidoRuleActive) || (stageVal === 'Pago' && isPagoRuleActive)
        ? stageVal 
        : targetCli.stage;

      const updatedCli = {
        ...targetCli,
        totalBought: boughtUpdate,
        lastPurchaseDate: new Date().toISOString().split('T')[0],
        stage: finalStage,
      };

      handleUpdateClient(updatedCli);

      // Save dynamic log history event
      handleAddHistoryEvent(
        newOrder.clientId,
        'order_created',
        ruleTriggerTitle,
        `${ruleTriggerText} Código: ${newOrder.id} - Total: R$ ${newOrder.total.toFixed(2)}`
      );

      // Inject simulated message into timeline
      const orderMessageText = `🛒 *PEDIDO GERADO:* Código: *${newOrder.id}*\n------------------------------\n${newOrder.items.map((it) => `${it.quantity}x ${it.productName}`).join('\n')}\n------------------------------\nTotal: *R$ ${newOrder.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}*\nForma de Pagamento: *${newOrder.paymentMethod}*\nStatus: *${newOrder.status === 'Pago' ? 'Aprovado ✅' : 'Aguardando Pagamento ⏳'}`;
      
      const timeNow = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      const systemMessage: Message = {
        id: `msg_sys_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        sender: 'sistema',
        text: orderMessageText,
        timestamp: timeNow,
      };

      setMessages((prev) => {
        const list = prev[newOrder.clientId] || [];
        return { ...prev, [newOrder.clientId]: [...list, systemMessage] };
      });
    }
  };

  const handleToggleAutomation = (ruleId: string) => {
    setAutomations((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, active: !r.active } : r))
    );
  };

  // 7. Calculate overall pipeline value
  const totalPipeline = clients
    .filter((c) => c.stage !== 'Fechado')
    .reduce((v, c) => v + (c.totalBought > 0 ? c.totalBought : 155), 0);

  const formatCurrency = (val: number) => {
    return `R$ ${val.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}`;
  };

  if (!auth.isAuthenticated) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className={`min-h-screen font-sans antialiased text-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-slate-100 flex transition-colors duration-150`}>
      
      {/* 1. Left Sidebar Navigation Panel */}
      <Sidebar
        currentTab={currentTab}
        onChangeTab={setCurrentTab}
        settings={settings}
        pipelineValue={formatCurrency(totalPipeline)}
        isOpenMobile={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* 2. Main Workspace Layout */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        
        {/* Header Workspace Options */}
        <Header
          settings={settings}
          onUpdateSettings={(s) => setSettings((prev) => ({ ...prev, ...s }))}
          onToggleMobileMenu={() => setMobileSidebarOpen(true)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onTriggerSync={handleTriggerSync}
          syncing={isSyncing}
          currentUser={auth.user || undefined}
          onLogout={handleLogout}
        />

        {/* Content Tabs Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
          {currentTab === 'dashboard' && (
            <DashboardView
              clients={clients}
              orders={orders}
              messages={messages}
              onChangeTab={setCurrentTab}
              onSelectClientInChat={setSelectedClient}
            />
          )}

          {currentTab === 'caixa' && <CaixaView />}

          {currentTab === 'whatsapp' && (
            <WhatsAppView
              clients={clients}
              messages={messages}
              onSendMessage={handleSendMessage}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={(id, type, head, desc) => handleAddHistoryEvent(id, type, head, desc)}
              selectedClient={selectedClient}
              onSelectClient={setSelectedClient}
              onOpenOrderModal={setClientForOrder}
            />
          )}

          {currentTab === 'crm' && (
            <CrmKanbanView
              clients={clients}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={handleAddHistoryEvent}
              onChangeTab={setCurrentTab}
              onSelectClientInChat={setSelectedClient}
            />
          )}

          {currentTab === 'campanhas' && (
            <CampanhasView
              campaigns={campaigns}
              onAddCampaign={(camp) => setCampaigns((prev) => [camp, ...prev])}
            />
          )}

          {currentTab === 'disparador' && (
            <DisparadorView
              clients={clients}
              settings={settings}
              onUpdateSettings={(s) => setSettings((prev) => ({ ...prev, ...s }))}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={handleAddHistoryEvent}
              onSendMessage={handleSendMessage}
            />
          )}

          {currentTab === 'cardapio' && (
            <CardapioView
              clients={clients}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={handleAddHistoryEvent}
              onSendMessage={handleSendMessage}
              cardapios={cardapios}
              setCardapios={setCardapios}
              products={productsDigitalMenu}
              setProducts={setProductsDigitalMenu}
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
            />
          )}

          {currentTab === 'cozinha' && (
            <CozinhaView
              clients={clients}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={handleAddHistoryEvent}
              onSendMessage={handleSendMessage}
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
              products={productsDigitalMenu}
              setProducts={setProductsDigitalMenu}
            />
          )}

          {currentTab === 'producao' && (
            <ProducaoView
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
            />
          )}

          {currentTab === 'entregas' && (
            <EntregasView
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
            />
          )}

          {currentTab === 'entregadores' && (
            <EntregadoresView
              couriers={couriers}
              setCouriers={setCouriers}
              reviews={reviews}
              setReviews={setReviews}
              deliveryOrders={deliveryOrders}
            />
          )}

          {currentTab === 'rotas' && (
            <RotasView
              couriers={couriers}
              setCouriers={setCouriers}
              routes={routes}
              setRoutes={setRoutes}
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
              messages={messages}
              setMessages={setMessages}
            />
          )}

          {currentTab === 'rastreamento' && (
            <RastreamentoView
              deliveryOrders={deliveryOrders}
              setDeliveryOrders={setDeliveryOrders}
              routes={routes}
              setRoutes={setRoutes}
              couriers={couriers}
              setCouriers={setCouriers}
              messages={messages}
            />
          )}

          {currentTab === 'pedidos' && (
            <div className="space-y-6 font-sans">
              <div>
                <h2 className="text-2xl font-bold tracking-tight text-slate-950 dark:text-white">Relatório Geral de Pedidos</h2>
                <p className="text-sm text-slate-550 dark:text-slate-400">Ordens de serviço faturadas pelo operador no chat.</p>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50/50 dark:bg-slate-805 border-b border-light-100 dark:border-slate-800 text-[10px] uppercase font-mono text-slate-400 tracking-wider">
                        <th className="py-3 px-4">Código</th>
                        <th className="py-3 px-4">Cliente</th>
                        <th className="py-3 px-4">Produtos Adquiridos</th>
                        <th className="py-3 px-4">Meio Pgto</th>
                        <th className="py-3 px-4">Total Ordem</th>
                        <th className="py-3 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                      {orders.map((ord) => (
                        <tr key={ord.id}>
                          <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">{ord.id}</td>
                          <td className="py-3.5 px-4 font-medium text-slate-700 dark:text-slate-350">{ord.clientName}</td>
                          <td className="py-3.5 px-4 max-w-[200px] truncate">{ord.items.map((i) => `${i.quantity}un. × ${i.productName}`).join(', ')}</td>
                          <td className="py-3.5 px-4 font-mono">{ord.paymentMethod}</td>
                          <td className="py-3.5 px-4 font-mono font-bold text-emerald-505 text-emerald-500">R$ {ord.total.toFixed(2)}</td>
                          <td className="py-3.5 px-4">
                            {ord.status === 'Pago' ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400">
                                PAGO
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400">
                                PENDENTE
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {currentTab === 'clientes' && (
            <ClientesView
              clients={clients}
              onUpdateClient={handleUpdateClient}
              onAddHistoryEvent={handleAddHistoryEvent}
            />
          )}

          {currentTab === 'automations' && (
            <AutomationsView
              rules={automations}
              onToggleRule={handleToggleAutomation}
            />
          )}

          {currentTab === 'central' && (
            <CentralInteligenteView
              clients={clients}
              orders={orders}
            />
          )}

          {currentTab === 'relatorios' && (
            <RelatoriosView
              clients={clients}
              orders={orders}
              campaigns={campaigns}
            />
          )}

          {currentTab === 'configuracoes' && (
            <ConfiguracoesView
              settings={settings}
              onUpdateSettings={(s) => setSettings((prev) => ({ ...prev, ...s }))}
              onResetDatabase={handleResetDatabase}
            />
          )}
        </main>
      </div>

      {/* 3. ABSOLUTE GLOBAL OVERLAYS: billing generation modal inside conversation workspace */}
      {clientForOrder && (
        <OrderModal
          client={clientForOrder}
          onClose={() => setClientForOrder(null)}
          onSaveOrder={handleSaveOrderCreated}
        />
      )}

    </div>
  );
}
